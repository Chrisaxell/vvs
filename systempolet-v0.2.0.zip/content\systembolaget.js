"use strict";
(() => {
  // src/lib/units.ts
  function isNum(v) {
    return typeof v === "number" && Number.isFinite(v);
  }
  function toMl(v) {
    if (v == null || !isFinite(v) || v <= 0) return void 0;
    if (v < 10) return Math.round(v * 1e3);
    if (v < 200) return Math.round(v * 10);
    return Math.round(v);
  }
  function formatVolume(ml) {
    if (ml == null || !isFinite(ml) || ml <= 0) return "";
    if (ml >= 1e3) {
      const l = ml / 1e3;
      if (Number.isInteger(l)) return `${l} L`;
      return `${l.toFixed(2).replace(/0+$/, "").replace(/\.$/, "")} L`;
    }
    if (ml % 10 === 0) return `${ml / 10} cl`;
    return `${ml} ml`;
  }
  function percentCheaper(cheaper, pricier) {
    if (!isNum(cheaper) || !isNum(pricier) || pricier <= 0) return void 0;
    if (cheaper >= pricier) return 0;
    return (pricier - cheaper) / pricier * 100;
  }

  // src/lib/banner.ts
  var HOST_ID = "vvs-banner-host";
  var FLAG_SE = "\u{1F1F8}\u{1F1EA}";
  var FLAG_NO = "\u{1F1F3}\u{1F1F4}";
  var WARN = "\u26A0";
  function renderBanner(source, result) {
    const host = ensureHost();
    const shadow = host.shadowRoot;
    const other = source.store === "systembolaget" ? result?.no : result?.se;
    const otherLabel = source.store === "systembolaget" ? "Vinmonopolet" : "Systembolaget";
    const otherFlag = source.store === "systembolaget" ? FLAG_NO : FLAG_SE;
    const alternates = result?.alternates ?? [];
    const otherLoneCurrencyLine = other && isNum(other.price) ? `<div class="row"><span class="price">${other.price.toFixed(0)} ${other.currency}</span></div>` : "";
    const pricesBlock = renderPricesBlock(result);
    const diffLine = renderDiff(result);
    const scoreLine = result && result.score > 0 ? `<span class="score" title="Match confidence">match ${(result.score * 100).toFixed(0)}%</span>` : "";
    const errLine = result?.searchError ? `<div class="soft-err" title="${escape(result.searchError)}">${WARN} Search failed: ${escape(shortenErr(result.searchError))}</div>` : "";
    const alternatesBlock = alternates.length ? `
      <details class="alts"${alternates.length > 1 ? " open" : ""}>
        <summary>${alternates.length === 1 ? "Other match" : `Other matches (${alternates.length})`}</summary>
        <ul>
          ${alternates.map((a) => renderAltItem(a.product, a.score)).join("")}
        </ul>
      </details>
    ` : "";
    const otherMeta = other ? renderMeta(other) : "";
    shadow.querySelector(".body").innerHTML = other ? `
      <div class="row">
        <div class="label">${otherFlag} ${escape(otherLabel)}</div>
        ${scoreLine}
      </div>
      <a class="name" href="${escape(other.url)}" target="_blank" rel="noopener">
        ${escape(other.name)}
      </a>
      ${otherMeta}
      ${pricesBlock || otherLoneCurrencyLine}
      ${diffLine}
      ${errLine}
      ${alternatesBlock}
    ` : alternates.length ? `
        <div class="row"><div class="label">${otherFlag} ${escape(otherLabel)}</div></div>
        <div class="muted">No confident match. Closest candidates:</div>
        <ul class="picker">
          ${alternates.map((a) => renderAltItem(a.product, a.score)).join("")}
        </ul>
        ${errLine}
      ` : `
        <div class="row"><div class="label">${otherFlag} ${escape(otherLabel)}</div></div>
        <div class="muted">${result?.searchError ? "Couldn't search the other store." : "No match found."}</div>
        ${errLine}
      `;
  }
  function renderMeta(p) {
    const parts = [];
    const vol = formatVolume(p.volumeMl);
    if (vol) parts.push(vol);
    if (isNum(p.abv)) parts.push(`${p.abv.toFixed(1)}%`);
    if (p.vintage) parts.push(String(p.vintage));
    if (parts.length === 0) return "";
    return `<div class="meta">${parts.map(escape).join(" \xB7 ")}</div>`;
  }
  function shortenErr(msg) {
    return msg.length > 80 ? `${msg.slice(0, 77)}\u2026` : msg;
  }
  function renderAltItem(p, score) {
    const price = isNum(p.price) ? `${p.price.toFixed(2)} ${p.currency}` : "\u2014";
    const vol = formatVolume(p.volumeMl);
    const volBadge = vol ? ` <span class="alt-vol">${escape(vol)}</span>` : "";
    return `
    <li>
      <a href="${escape(p.url)}" target="_blank" rel="noopener" title="match ${(score * 100).toFixed(0)}%">
        <span class="alt-name">${escape(p.name)}${volBadge}</span>
        <span class="alt-price">${price}</span>
      </a>
    </li>
  `;
  }
  function renderLoading(source) {
    const host = ensureHost();
    const shadow = host.shadowRoot;
    const otherLabel = source.store === "systembolaget" ? "Vinmonopolet" : "Systembolaget";
    const otherFlag = source.store === "systembolaget" ? FLAG_NO : FLAG_SE;
    shadow.querySelector(".body").innerHTML = `
    <div class="row"><div class="label">${otherFlag} ${otherLabel}</div></div>
    <div class="muted">Searching\u2026</div>
  `;
  }
  function renderWelcome(sourceStore, autoHideMs = 8e3) {
    const host = ensureHost();
    const shadow = host.shadowRoot;
    const otherLabel = sourceStore === "systembolaget" ? "Vinmonopolet" : "Systembolaget";
    const otherFlag = sourceStore === "systembolaget" ? FLAG_NO : FLAG_SE;
    const otherUrl = sourceStore === "systembolaget" ? "https://www.vinmonopolet.no/" : "https://www.systembolaget.se/";
    shadow.querySelector(".body").innerHTML = `
    <div class="row"><div class="label">Systempolet is watching</div></div>
    <div class="welcome">
      Browse any product and we'll show you the price at
      <a class="welcome-link" href="${escape(otherUrl)}" target="_blank" rel="noopener">
        <strong>${otherFlag} ${escape(otherLabel)}</strong> \u2197
      </a>.
    </div>
  `;
    if (autoHideMs > 0) {
      window.setTimeout(() => {
        if (shadow.querySelector(".welcome")) host.remove();
      }, autoHideMs);
    }
  }
  function renderError(msg) {
    const host = ensureHost();
    const shadow = host.shadowRoot;
    shadow.querySelector(".body").innerHTML = `
    <div class="row"><div class="label">${WARN} Error</div></div>
    <div class="muted">${escape(msg)}</div>
  `;
  }
  function renderDiff(result) {
    if (!result || !result.se || !result.no) return "";
    if (!isNum(result.priceDiffSek) || !isNum(result.fxRate)) return "";
    if (!isNum(result.se.price) || !isNum(result.no.price)) return "";
    const diff = result.priceDiffSek;
    const abs = Math.abs(diff).toFixed(0);
    if (Math.abs(diff) < 1) {
      return `<div class="diff neutral">Prices are essentially equal.</div>`;
    }
    const noCheaper = diff < 0;
    const cheaperFlag = noCheaper ? FLAG_NO : FLAG_SE;
    const cheaperName = noCheaper ? "Vinmonopolet" : "Systembolaget";
    const seSek = result.se.price;
    const noSek = result.no.price * result.fxRate;
    const bottlePct = percentCheaper(Math.min(seSek, noSek), Math.max(seSek, noSek)) ?? 0;
    let headlinePct = bottlePct;
    let headlineIsPerLitre = false;
    let headlineFlag = cheaperFlag;
    let headlineName = cheaperName;
    let perLitreDetail = "";
    if (isNum(result.seSekPerLitre) && isNum(result.noSekPerLitre)) {
      const seL = result.seSekPerLitre;
      const noL = result.noSekPerLitre;
      const perLitreCheaper = noL < seL;
      const perLitrePct = percentCheaper(Math.min(seL, noL), Math.max(seL, noL)) ?? 0;
      headlinePct = perLitrePct;
      headlineIsPerLitre = true;
      headlineFlag = perLitreCheaper ? FLAG_NO : FLAG_SE;
      headlineName = perLitreCheaper ? "Vinmonopolet" : "Systembolaget";
      perLitreDetail = `<div class="diff-sub">${Math.min(seL, noL).toFixed(0)} vs ${Math.max(seL, noL).toFixed(0)} SEK/L</div>`;
    }
    const perBottleDetail = headlineIsPerLitre ? `<div class="diff-sub">Per bottle: ${cheaperFlag} <strong>${cheaperName}</strong> saves <strong>${abs} SEK</strong> (${bottlePct.toFixed(0)}%)</div>` : `<div class="diff-sub">Saves <strong>${abs} SEK</strong> per bottle</div>`;
    const winnerClass = headlineName === "Vinmonopolet" ? "no" : "se";
    const unitLabel = headlineIsPerLitre ? "per litre" : "per bottle";
    return `<div class="diff ${winnerClass}">
    <div class="diff-headline">
      ${headlineFlag} <strong>${headlineName}</strong> is
      <span class="diff-pct">${headlinePct.toFixed(0)}%</span> cheaper
      <span class="diff-unit">${unitLabel}</span>
    </div>
    ${perLitreDetail}
    ${perBottleDetail}
  </div>`;
  }
  function renderPricesBlock(result) {
    if (!result?.se || !result?.no || !isNum(result.fxRate)) return "";
    if (!isNum(result.se.price) || !isNum(result.no.price)) return "";
    const seSek = result.se.price;
    const noNok = result.no.price;
    const noSek = noNok * result.fxRate;
    const usingPerLitre = isNum(result.seSekPerLitre) && isNum(result.noSekPerLitre);
    const seCompare = usingPerLitre ? result.seSekPerLitre : seSek;
    const noCompare = usingPerLitre ? result.noSekPerLitre : noSek;
    const seCheaper = seCompare < noCompare;
    const savings = percentCheaper(Math.min(seCompare, noCompare), Math.max(seCompare, noCompare));
    console.log("[vvs] renderPricesBlock:", {
      seVolumeMl: result.se.volumeMl,
      noVolumeMl: result.no.volumeMl,
      seSekPerLitre: result.seSekPerLitre,
      noSekPerLitre: result.noSekPerLitre,
      usingPerLitre,
      seCompare,
      noCompare,
      savings,
      willBadge: isNum(savings) && savings >= 1
    });
    const sePerL = isNum(result.seSekPerLitre) ? `<div class="price-sub">${result.seSekPerLitre.toFixed(0)} SEK/L</div>` : "";
    const noPerL = isNum(result.noSekPerLitre) ? `<div class="price-sub">${result.noSekPerLitre.toFixed(0)} SEK/L</div>` : "";
    const saveLabel = usingPerLitre ? "SAVE" : "SAVE";
    const seSaveBadge = isNum(savings) && seCheaper && savings >= 1 ? `<div class="save-badge">${saveLabel} ${savings.toFixed(0)}%</div>` : "";
    const noSaveBadge = isNum(savings) && !seCheaper && savings >= 1 ? `<div class="save-badge">${saveLabel} ${savings.toFixed(0)}%</div>` : "";
    return `
    <div class="prices">
      <div class="price-cell${seCheaper && isNum(savings) && savings >= 1 ? " winner" : ""}">
        <div class="price-flag">${FLAG_SE} SE</div>
        <div class="price-main">${seSek.toFixed(0)} SEK</div>
        ${sePerL}
        ${seSaveBadge}
      </div>
      <div class="price-cell${!seCheaper && isNum(savings) && savings >= 1 ? " winner" : ""}">
        <div class="price-flag">${FLAG_NO} NO</div>
        <div class="price-main">${noNok.toFixed(0)} NOK</div>
        <div class="price-sub">\u2248 ${noSek.toFixed(0)} SEK</div>
        ${noPerL}
        ${noSaveBadge}
      </div>
    </div>
  `;
  }
  function escape(s) {
    return s.replace(
      /[&<>"']/g,
      (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
    );
  }
  function ensureHost() {
    const existing = document.getElementById(HOST_ID);
    if (existing) return existing;
    const host = document.createElement("div");
    host.id = HOST_ID;
    host.style.cssText = [
      "position: fixed !important",
      "bottom: 16px !important",
      "right: 16px !important",
      "top: auto !important",
      "left: auto !important",
      "z-index: 2147483647 !important",
      "width: auto !important",
      "height: auto !important",
      "max-width: 320px !important",
      "display: block !important",
      "visibility: visible !important",
      "opacity: 1 !important",
      "margin: 0 !important",
      "padding: 0 !important",
      "border: 0 !important",
      "transform: none !important",
      "pointer-events: auto !important"
    ].join("; ");
    const shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML = `
    <style>
      :host { all: initial; }
      .card {
        font-family: system-ui, -apple-system, "Segoe UI", sans-serif;
        font-size: 13px;
        color: #f5f5f5;
        background: #14161a;
        border: 1px solid #2a2f37;
        border-radius: 10px;
        padding: 12px 14px;
        width: 280px;
        box-shadow: 0 8px 24px rgba(0,0,0,0.4);
      }
      .head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 6px;
      }
      .brand { color: #e0b25a; font-weight: 700; letter-spacing: 0.5px; }
      .close {
        cursor: pointer; color: #9aa0a6; background: none; border: 0;
        font-size: 16px; line-height: 1; padding: 0 4px;
      }
      .close:hover { color: #f5f5f5; }
      .body { display: flex; flex-direction: column; gap: 6px; }
      .row { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
      .label { color: #9aa0a6; font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; }
      .name { color: #f5f5f5; font-weight: 600; text-decoration: none; }
      .name:hover { text-decoration: underline; }
      .price { color: #e0b25a; font-weight: 700; }
      .muted { color: #9aa0a6; font-size: 12px; }
      .meta { color: #9aa0a6; font-size: 11px; margin-top: -2px; }
      .score {
        color: #9aa0a6; background: #1e2127; border: 1px solid #2a2f37;
        border-radius: 999px; padding: 1px 8px; font-size: 11px;
      }
      .diff { font-size: 12px; font-weight: 600; }
      .diff.se { color: #7ec9ff; }
      .diff.no { color: #7ee787; }
      .diff.neutral { color: #9aa0a6; }
      div.diff {
        margin-top: 6px; padding: 6px 8px; border-radius: 4px;
        background: #1e2127; border: 1px solid #2a2f37; line-height: 1.35;
      }
      .diff-sub {
        margin-top: 4px; padding-top: 4px;
        border-top: 1px dashed #2a2f37;
        font-size: 11px; color: #9aa0a6; font-weight: normal;
      }
      .diff-sub strong { color: #f5f5f5; }
      .diff-headline {
        display: flex; align-items: baseline; flex-wrap: wrap; gap: 4px;
        font-size: 14px; line-height: 1.2;
      }
      .diff-pct {
        font-size: 24px; font-weight: 800; line-height: 1;
        color: #7ee787;
        padding: 0 2px;
      }
      .diff.se .diff-pct { color: #7ec9ff; }
      .diff.no .diff-pct { color: #7ee787; }
      .diff-unit { color: #9aa0a6; font-size: 11px; font-weight: normal; }
      .prices {
        display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 4px;
      }
      .price-cell {
        background: #1e2127; border: 1px solid #2a2f37; border-radius: 6px;
        padding: 6px 8px; text-align: center;
        position: relative;
        transition: border-color 0.15s ease;
      }
      .price-cell.winner {
        border-color: #7ee787;
        box-shadow: 0 0 0 1px rgba(126, 231, 135, 0.25);
      }
      .price-flag {
        color: #9aa0a6; font-size: 10px; text-transform: uppercase;
        letter-spacing: 0.5px; margin-bottom: 2px;
      }
      .price-main { color: #e0b25a; font-weight: 700; font-size: 14px; }
      .price-sub { color: #9aa0a6; font-size: 10px; margin-top: 1px; }
      .save-badge {
        display: inline-block;
        margin-top: 4px;
        padding: 2px 6px;
        background: #7ee787;
        color: #14161a;
        font-size: 10px;
        font-weight: 800;
        letter-spacing: 0.5px;
        border-radius: 3px;
      }
      .alts {
        margin-top: 4px; border-top: 1px dashed #2a2f37; padding-top: 6px;
      }
      .alts summary {
        cursor: pointer; color: #9aa0a6; font-size: 11px;
        text-transform: uppercase; letter-spacing: 0.5px;
        list-style: none; user-select: none;
      }
      .alts summary::-webkit-details-marker { display: none; }
      .alts summary::before { content: "\u25B8 "; }
      .alts[open] summary::before { content: "\u25BE "; }
      ul.picker, .alts ul {
        list-style: none; margin: 6px 0 0; padding: 0;
        display: flex; flex-direction: column; gap: 4px;
      }
      ul.picker li a, .alts ul li a {
        display: flex; justify-content: space-between; align-items: center;
        gap: 8px; color: #f5f5f5; text-decoration: none; font-size: 12px;
        padding: 4px 6px; border-radius: 4px;
      }
      ul.picker li a:hover, .alts ul li a:hover {
        background: #1e2127; color: #e0b25a;
      }
      .alt-name {
        overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
        flex: 1 1 auto; min-width: 0;
      }
      .alt-price { color: #e0b25a; font-weight: 600; flex: 0 0 auto; }
      .alt-vol {
        display: inline-block; background: #14161a; border: 1px solid #2a2f37;
        border-radius: 3px; padding: 0 4px; margin-left: 4px;
        font-size: 10px; color: #9aa0a6; font-weight: normal; vertical-align: middle;
      }
      .welcome { color: #f5f5f5; font-size: 13px; line-height: 1.4; }
      .welcome-link { color: #e0b25a; text-decoration: none; white-space: nowrap; }
      .welcome-link:hover { text-decoration: underline; }
      .soft-err {
        margin-top: 6px; padding: 6px 8px; border-radius: 4px;
        background: #3a2a1a; border: 1px solid #6b4a2a; color: #ffb977;
        font-size: 11px; line-height: 1.35;
      }
    </style>
    <div class="card">
      <div class="head">
        <span class="brand">Systempolet</span>
        <button class="close" title="Hide">\u2715</button>
      </div>
      <div class="body"></div>
    </div>
  `;
    shadow.querySelector(".close").addEventListener("click", () => {
      host.remove();
    });
    document.documentElement.appendChild(host);
    return host;
  }

  // src/lib/systembolaget.ts
  var SITE = "https://www.systembolaget.se";
  function toProduct(p) {
    const id = p.productNumber ?? p.productId ?? p.productNumberShort;
    const nameParts = [p.productNameBold, p.productNameThin].filter(Boolean).join(" ").trim();
    const name = nameParts || void 0;
    const price = typeof p.price === "number" ? p.price : void 0;
    if (!id || !name || price == null) return void 0;
    const slug = p.slug ?? `${name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`;
    const url = `${SITE}/produkt/${p.categoryLevel1?.toLowerCase() ?? "ovrigt"}/${slug}-${id}/`;
    const image = p.images?.[0]?.imageUrl;
    const imageUrl = image ? image.startsWith("http") ? image : `https:${image}` : void 0;
    return {
      store: "systembolaget",
      id: String(id),
      name,
      producer: p.producerName,
      country: p.country,
      volumeMl: toMl(p.volume),
      abv: typeof p.alcoholPercentage === "number" ? p.alcoholPercentage : void 0,
      vintage: p.vintage ? Number(p.vintage) || void 0 : void 0,
      price,
      currency: "SEK",
      url,
      imageUrl
    };
  }
  function extractNextData(html) {
    const match = html.match(
      /<script[^>]+id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/
    );
    if (!match) return void 0;
    try {
      return JSON.parse(match[1]);
    } catch (err) {
      console.warn("[vvs] failed to parse __NEXT_DATA__:", err);
      return void 0;
    }
  }
  function findProductArrays(node, out = []) {
    if (!node || typeof node !== "object") return out;
    if (Array.isArray(node)) {
      if (node.length > 0 && typeof node[0] === "object" && node[0] !== null && ("productNumber" in node[0] || "productId" in node[0])) {
        out.push(node);
      }
      for (const item of node) findProductArrays(item, out);
      return out;
    }
    for (const v of Object.values(node)) findProductArrays(v, out);
    return out;
  }
  async function searchSystembolaget(query, pageSize = 10) {
    const url = `${SITE}/sortiment/?q=${encodeURIComponent(query)}`;
    let res;
    try {
      res = await fetch(url, {
        headers: {
          Accept: "text/html,application/xhtml+xml",
          "Accept-Language": "sv-SE,sv;q=0.9,en;q=0.8",
          // Systembolaget's edge sometimes 403s requests without a UA.
          "User-Agent": "Mozilla/5.0 (compatible; vvs-extension/0.2)"
        }
      });
    } catch (err) {
      console.warn("[vvs] Systembolaget search fetch failed:", err);
      return [];
    }
    if (!res.ok) {
      if (res.status === 429 || res.status >= 500) {
        console.warn(`[vvs] Systembolaget search transient HTTP ${res.status}, returning []`);
        return [];
      }
      throw new Error(`Systembolaget search HTTP ${res.status}`);
    }
    const html = await res.text();
    const data = extractNextData(html);
    if (!data) {
      console.warn("[vvs] Systembolaget search: no __NEXT_DATA__ in response");
      return [];
    }
    const arrays = findProductArrays(data);
    arrays.sort((a, b) => b.length - a.length);
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    for (const arr of arrays) {
      for (const raw of arr) {
        const p = toProduct(raw);
        if (!p) continue;
        if (seen.has(p.id)) continue;
        seen.add(p.id);
        out.push(p);
        if (out.length >= pageSize) return out;
      }
    }
    return out;
  }
  async function getSystembolagetProduct(id) {
    const results = await searchSystembolaget(id, 5);
    return results.find((p) => p.id === id) ?? results[0];
  }
  function parseSystembolagetUrl(url) {
    const m = url.match(/-(\d{4,7})(?:-\d{2})?(?:[/?#]|$)/);
    return m?.[1];
  }

  // src/content/systembolaget.ts
  console.log("[vvs] systembolaget content script loaded on", location.href);
  try {
    chrome.runtime.sendMessage({ type: "SCRIPT_LOADED", store: "systembolaget", url: location.href }).catch((err) => console.warn("[vvs] SCRIPT_LOADED send failed:", err));
  } catch (err) {
    console.warn("[vvs] cannot reach background worker:", err);
  }
  var lastHandledId;
  var greeted = false;
  async function handle() {
    const id = parseSystembolagetUrl(location.href);
    console.log("[vvs] systembolaget parseUrl ->", id ?? "(no id)");
    if (!id) {
      if (!greeted) {
        greeted = true;
        try {
          renderWelcome("systembolaget");
        } catch (err) {
          console.error("[vvs] renderWelcome failed:", err);
        }
      }
      return;
    }
    if (id === lastHandledId) return;
    lastHandledId = id;
    greeted = true;
    const provisional = {
      store: "systembolaget",
      id,
      name: "Loading product\u2026",
      price: NaN,
      currency: "SEK",
      url: location.href
    };
    try {
      renderLoading(provisional);
    } catch (err) {
      console.error("[vvs] renderLoading failed:", err);
    }
    try {
      let product;
      for (const delay of [0, 400, 1200]) {
        if (delay > 0) await new Promise((r) => setTimeout(r, delay));
        const attempt = scrapeFromDom(id);
        if (attempt) {
          product = mergeProducts(product, attempt);
          if (isNum(product.price) && product.name && product.name !== "Loading product\u2026") break;
        }
      }
      if (!product || !isNum(product.price)) {
        console.log("[vvs] DOM incomplete, trying search fallback for id", id);
        try {
          const searched = await getSystembolagetProduct(id);
          if (searched) product = mergeProducts(product, searched);
        } catch (err) {
          console.warn("[vvs] search fallback failed:", err);
        }
      }
      if (!product || !product.name || product.name === "Loading product\u2026") {
        const slugName = extractNameFromUrl(location.href);
        if (slugName) {
          product = {
            store: "systembolaget",
            id,
            name: slugName,
            price: product?.price ?? NaN,
            currency: "SEK",
            url: location.href
          };
          console.log("[vvs] using URL-slug fallback product:", product);
        }
      }
      if (!product) {
        console.warn("[vvs] systembolaget: could not build product for id", id);
        renderError(`Could not read product ${id} from this page.`);
        return;
      }
      console.log("[vvs] systembolaget product:", product);
      void sendMessage({ type: "PAGE_PRODUCT", product });
      renderLoading(product);
      const result = await sendMessage({ type: "FIND_MATCH", product });
      console.log("[vvs] comparison result:", result);
      renderBanner(product, result);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      console.error("[vvs] systembolaget handle failed:", err);
      try {
        renderError(msg);
      } catch (e2) {
        console.error("[vvs] renderError failed:", e2);
      }
    }
  }
  function mergeProducts(a, b) {
    if (!a) return b;
    return {
      store: b.store,
      id: b.id || a.id,
      name: b.name && b.name !== "Loading product\u2026" ? b.name : a.name,
      producer: b.producer ?? a.producer,
      country: b.country ?? a.country,
      category: b.category ?? a.category,
      volumeMl: b.volumeMl ?? a.volumeMl,
      abv: b.abv ?? a.abv,
      vintage: b.vintage ?? a.vintage,
      price: isNum(b.price) ? b.price : a.price,
      currency: b.currency || a.currency,
      url: b.url || a.url,
      imageUrl: b.imageUrl ?? a.imageUrl
    };
  }
  function extractNameFromUrl(url) {
    const m = url.match(/\/produkt\/[^/]+\/([^/]+?)(?:-\d{4,7})(?:-\d{2})?\/?(?:[?#]|$)/);
    if (!m) return void 0;
    return m[1].split("-").filter(Boolean).map((s) => s.charAt(0).toUpperCase() + s.slice(1)).join(" ");
  }
  function scrapeFromDom(id) {
    let name;
    let price = NaN;
    let producer;
    let imageUrl;
    let currency = "SEK";
    for (const el of Array.from(document.querySelectorAll('script[type="application/ld+json"]'))) {
      try {
        const data = JSON.parse(el.textContent ?? "");
        const nodes = Array.isArray(data) ? data : [data];
        for (const node of nodes) {
          if (!node || node["@type"] !== "Product") continue;
          if (!name && node.name) name = String(node.name).trim();
          if (!producer && node.brand) producer = node.brand?.name ?? node.brand;
          if (!imageUrl && node.image) {
            imageUrl = typeof node.image === "string" ? node.image : node.image?.[0];
          }
          const offer = Array.isArray(node.offers) ? node.offers[0] : node.offers;
          const p = Number(offer?.price);
          if (isNum(p) && !isNum(price)) price = p;
          if (offer?.priceCurrency) currency = offer.priceCurrency;
        }
      } catch {
      }
    }
    if (!name) {
      const og = document.querySelector('meta[property="og:title"]')?.getAttribute("content");
      if (og) name = og.trim();
    }
    if (!isFinite(price)) {
      const ogPrice = document.querySelector('meta[property="product:price:amount"]')?.getAttribute("content") ?? document.querySelector('meta[property="og:price:amount"]')?.getAttribute("content");
      if (ogPrice) {
        const p = Number(ogPrice.replace(",", "."));
        if (isFinite(p)) price = p;
      }
    }
    if (!imageUrl) {
      const ogImg = document.querySelector('meta[property="og:image"]')?.getAttribute("content");
      if (ogImg) imageUrl = ogImg;
    }
    const nextEl = document.getElementById("__NEXT_DATA__");
    if (nextEl?.textContent) {
      try {
        const data = JSON.parse(nextEl.textContent);
        const found = findProductInObject(data, id);
        if (found) {
          if (!name && found.name) name = found.name;
          if (!producer && found.producer) producer = found.producer;
          if (!isFinite(price) && isFinite(found.price)) price = found.price;
          if (!imageUrl && found.imageUrl) imageUrl = found.imageUrl;
        }
      } catch {
      }
    }
    if (!name) {
      const h1 = document.querySelector("h1")?.textContent?.trim();
      if (h1) name = h1;
    }
    if (!isFinite(price)) {
      const priceEl = document.querySelector('[class*="price" i], [data-testid*="price" i]');
      const txt = priceEl?.textContent ?? "";
      const m = txt.match(/(\d+[.,]?\d*)\s*(?:kr|SEK)/i);
      if (m) {
        const p = Number(m[1].replace(",", "."));
        if (isFinite(p)) price = p;
      }
    }
    if (!name && !isFinite(price)) return void 0;
    return {
      store: "systembolaget",
      id,
      name: name ?? "",
      producer,
      price,
      currency,
      url: location.href,
      imageUrl
    };
  }
  function findProductInObject(node, id) {
    if (!node || typeof node !== "object") return void 0;
    if (Array.isArray(node)) {
      for (const item of node) {
        const found = findProductInObject(item, id);
        if (found) return found;
      }
      return void 0;
    }
    const obj = node;
    const productNumber = obj.productNumber ?? obj.productId;
    if (typeof productNumber === "string" && productNumber === id) {
      const nameBold = obj.productNameBold;
      const nameThin = obj.productNameThin;
      const name = [nameBold, nameThin].filter(Boolean).join(" ").trim() || String(obj.name ?? "").trim();
      return {
        store: "systembolaget",
        id,
        name: name || "Unknown",
        producer: obj.producerName,
        country: obj.country,
        volumeMl: toMl(typeof obj.volume === "number" ? obj.volume : void 0),
        abv: typeof obj.alcoholPercentage === "number" ? obj.alcoholPercentage : void 0,
        price: typeof obj.price === "number" ? obj.price : NaN,
        currency: "SEK",
        url: location.href
      };
    }
    for (const v of Object.values(obj)) {
      const found = findProductInObject(v, id);
      if (found) return found;
    }
    return void 0;
  }
  async function sendMessage(message) {
    const res = await chrome.runtime.sendMessage(message);
    if (!res) return void 0;
    if (!res.ok) throw new Error(res.error ?? "Unknown extension error");
    return res.data;
  }
  function watchNavigation() {
    let lastHref = location.href;
    const check = () => {
      if (location.href !== lastHref) {
        lastHref = location.href;
        console.log("[vvs] navigation ->", lastHref);
        void handle();
      }
    };
    const attachObserver = () => {
      if (!document.body) return false;
      new MutationObserver(check).observe(document.body, { childList: true, subtree: true });
      return true;
    };
    if (!attachObserver()) {
      document.addEventListener("DOMContentLoaded", attachObserver, { once: true });
    }
    const wrap = (name) => {
      const orig = history[name];
      history[name] = function() {
        const r = orig.apply(this, arguments);
        queueMicrotask(check);
        return r;
      };
    };
    wrap("pushState");
    wrap("replaceState");
    window.addEventListener("popstate", check);
  }
  try {
    void handle();
    watchNavigation();
  } catch (err) {
    console.error("[vvs] systembolaget boot failed:", err);
  }
})();
//# sourceMappingURL=systembolaget.js.map
