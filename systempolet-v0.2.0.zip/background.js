// src/lib/storage.ts
var KEYS = {
  lastSeen: "lastSeenProduct",
  lastComparison: "lastComparison",
  fxRate: "fxRateSekPerNok",
  fxUpdatedAt: "fxUpdatedAt",
  vmpPrimaryKey: "vmpPrimaryKey",
  vmpSecondaryKey: "vmpSecondaryKey"
};
async function setLastSeen(product) {
  await chrome.storage.local.set({ [KEYS.lastSeen]: product });
}
async function getLastSeen() {
  const res = await chrome.storage.local.get(KEYS.lastSeen);
  return res[KEYS.lastSeen];
}
async function setLastComparison(comparison) {
  await chrome.storage.local.set({ [KEYS.lastComparison]: comparison });
}
async function getLastComparison() {
  const res = await chrome.storage.local.get(KEYS.lastComparison);
  return res[KEYS.lastComparison];
}
async function setFxRate(sekPerNok) {
  await chrome.storage.local.set({
    [KEYS.fxRate]: sekPerNok,
    [KEYS.fxUpdatedAt]: Date.now()
  });
}
async function getFxRate() {
  const res = await chrome.storage.local.get([KEYS.fxRate, KEYS.fxUpdatedAt]);
  const rate = res[KEYS.fxRate];
  const updatedAt = res[KEYS.fxUpdatedAt];
  if (rate == null || updatedAt == null) return void 0;
  return { rate, updatedAt };
}
async function getVmpKeys() {
  const res = await chrome.storage.local.get([KEYS.vmpPrimaryKey, KEYS.vmpSecondaryKey]);
  return {
    primary: res[KEYS.vmpPrimaryKey] || void 0,
    secondary: res[KEYS.vmpSecondaryKey] || void 0
  };
}

// src/lib/currency.ts
var ONE_DAY_MS = 24 * 60 * 60 * 1e3;
var FALLBACK_SEK_PER_NOK = 0.92;
async function getSekPerNok() {
  const cached = await getFxRate();
  if (cached && Date.now() - cached.updatedAt < ONE_DAY_MS) {
    return cached.rate;
  }
  try {
    const res = await fetch("https://api.frankfurter.app/latest?from=NOK&to=SEK");
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    const rate = json.rates?.SEK;
    if (typeof rate !== "number" || !isFinite(rate)) throw new Error("Bad rate");
    await setFxRate(rate);
    return rate;
  } catch (err) {
    console.warn("[vvs] FX fetch failed, using fallback:", err);
    return cached?.rate ?? FALLBACK_SEK_PER_NOK;
  }
}
function nokToSek(nok, rate) {
  return nok * rate;
}

// src/lib/units.ts
function isNum(v) {
  return typeof v === "number" && Number.isFinite(v);
}
function toMl(v) {
  if (v == null || !isFinite(v) || v <= 0) return void 0;
  if (v < 10) return Math.round(v * 1e3);
  if (v < 200) return Math.round(v * 10);
  return Math.round(v);
}
function pricePerLitre(price, volumeMl) {
  if (!isNum(price) || !isNum(volumeMl) || volumeMl <= 0) return void 0;
  return price / (volumeMl / 1e3);
}

// src/lib/compare.ts
function normalizeName(name) {
  return name.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/\b(19|20)\d{2}\b/g, " ").replace(/\b\d+(?:[.,]\d+)?\s?(?:cl|ml|l|%)\b/gi, " ").replace(/\bno\.?\s?(\d+)\b/gi, "no$1").replace(/[^\p{Letter}\p{Number}\s]/gu, " ").replace(/\s+/g, " ").trim();
}
function tokens(name) {
  const stop = /* @__PURE__ */ new Set([
    "the",
    "and",
    "og",
    "och",
    "de",
    "la",
    "le",
    "les",
    "di",
    "du",
    "del",
    "della",
    "da",
    "vin",
    "vino",
    "wine",
    "rouge",
    "blanc"
  ]);
  return normalizeName(name).split(" ").filter((t) => t.length > 0 && !stop.has(t));
}
function diceBigram(a, b) {
  const bigrams = (s) => {
    const m = /* @__PURE__ */ new Map();
    const t = ` ${s} `;
    for (let i = 0; i < t.length - 1; i++) {
      const bg = t.slice(i, i + 2);
      m.set(bg, (m.get(bg) ?? 0) + 1);
    }
    return m;
  };
  const A = bigrams(a);
  const B = bigrams(b);
  if (A.size === 0 || B.size === 0) return 0;
  let overlap = 0;
  for (const [bg, count] of A) {
    const other = B.get(bg);
    if (other) overlap += Math.min(count, other);
  }
  const total = [...A.values()].reduce((s, n) => s + n, 0) + [...B.values()].reduce((s, n) => s + n, 0);
  return 2 * overlap / total;
}
function similarity(a, b) {
  const at = new Set(tokens(a));
  const bt = new Set(tokens(b));
  if (at.size === 0 || bt.size === 0) return 0;
  let intersect = 0;
  for (const t of at) if (bt.has(t)) intersect++;
  const jaccard = intersect / (at.size + bt.size - intersect);
  const bigram = diceBigram(normalizeName(a), normalizeName(b));
  return 0.55 * jaccard + 0.45 * bigram;
}
function hasVariantConflict(a, b) {
  const variantMarkers = /* @__PURE__ */ new Set([
    "vanilla",
    "vanille",
    "lime",
    "cherry",
    "raspberry",
    "peach",
    "apple",
    "strawberry",
    "watermelon",
    "citrus",
    "orange",
    "mango",
    "passion",
    "honey",
    "spiced",
    "gold",
    "silver",
    "black",
    "red",
    "white",
    "blue",
    "green",
    "reserve",
    "special",
    "limited",
    "blueberry",
    "chocolate",
    "coffee",
    "caramel",
    "mint",
    "ginger",
    "cucumber",
    "rose"
  ]);
  const at = new Set(tokens(a.name));
  const bt = new Set(tokens(b.name));
  for (const m of variantMarkers) {
    if (at.has(m) !== bt.has(m)) return true;
  }
  return false;
}
function scoreMatch(source, candidate) {
  let score = similarity(source.name, candidate.name);
  if (source.producer && candidate.producer) {
    const pSim = similarity(source.producer, candidate.producer);
    score = 0.7 * score + 0.3 * pSim;
  }
  if (source.volumeMl && candidate.volumeMl) {
    const ratio = Math.min(source.volumeMl, candidate.volumeMl) / Math.max(source.volumeMl, candidate.volumeMl);
    if (ratio > 0.95) score += 0.08;
    else if (ratio > 0.5) score -= 0.05;
    else score -= 0.25;
  }
  if (isNum(source.abv) && isNum(candidate.abv)) {
    const abvDiff = Math.abs(source.abv - candidate.abv);
    if (abvDiff <= 0.5) score += 0.08;
    else if (abvDiff <= 2) score += 0.02;
    else if (abvDiff <= 5) score -= 0.08;
    else score -= 0.3;
  }
  const srcNums = tokens(source.name).filter((t) => /\d/.test(t));
  const candNums = tokens(candidate.name).filter((t) => /\d/.test(t));
  if (srcNums.length > 0 && candNums.length > 0) {
    const matchingNums = srcNums.filter((n) => candNums.includes(n)).length;
    if (matchingNums === 0) score -= 0.15;
    else score += 0.1 * matchingNums / Math.max(srcNums.length, candNums.length);
  } else if (srcNums.length !== candNums.length) {
    score -= 0.05;
  }
  if (hasVariantConflict(source, candidate)) score -= 0.2;
  return Math.max(0, Math.min(1, score));
}
function bestMatch(source, candidates, minScore = 0.35) {
  let best;
  let bestScore = 0;
  for (const c of candidates) {
    const s = scoreMatch(source, c);
    if (s > bestScore) {
      bestScore = s;
      best = c;
    }
  }
  return best && bestScore >= minScore ? { product: best, score: bestScore } : void 0;
}
function topMatches(source, candidates, n = 3) {
  const scored = candidates.map((product) => ({ product, score: scoreMatch(source, product) })).filter((s) => s.score > 0);
  scored.sort((a, b) => b.score - a.score);
  const seen = /* @__PURE__ */ new Set();
  const unique = [];
  for (const s of scored) {
    if (seen.has(s.product.id)) continue;
    seen.add(s.product.id);
    unique.push(s);
    if (unique.length >= n) break;
  }
  return unique;
}
async function compare(se, no, score = 0, alternates = []) {
  const result = { se, no, score, alternates };
  if (se && no && isNum(se.price) && isNum(no.price)) {
    const rate = await getSekPerNok();
    result.priceDiffSek = nokToSek(no.price, rate) - se.price;
    result.fxRate = rate;
    const sePerLitre = pricePerLitre(se.price, se.volumeMl);
    const noPerLitreNok = pricePerLitre(no.price, no.volumeMl);
    if (isNum(sePerLitre)) result.seSekPerLitre = sePerLitre;
    if (isNum(noPerLitreNok)) result.noSekPerLitre = noPerLitreNok * rate;
  }
  return result;
}

// src/lib/systembolaget.ts
var SITE = "https://www.systembolaget.se";
function toProduct(p) {
  const id = p.productNumber ?? p.productId ?? p.productNumberShort;
  const nameParts = [p.productNameBold, p.productNameThin].filter(Boolean).join(" ").trim();
  const name = nameParts || void 0;
  const price = typeof p.price === "number" ? p.price : void 0;
  if (!id || !name || price == null) return void 0;
  const slug = p.slug ?? `${name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`;
  const url = `${SITE}/produkt/${p.categoryLevel1?.toLowerCase() ?? "ovrigt"}/${slug}-${id}/`;
  const image = p.images?.[0]?.imageUrl;
  const imageUrl = image ? image.startsWith("http") ? image : `https:${image}` : void 0;
  return {
    store: "systembolaget",
    id: String(id),
    name,
    producer: p.producerName,
    country: p.country,
    volumeMl: toMl(p.volume),
    abv: typeof p.alcoholPercentage === "number" ? p.alcoholPercentage : void 0,
    vintage: p.vintage ? Number(p.vintage) || void 0 : void 0,
    price,
    currency: "SEK",
    url,
    imageUrl
  };
}
function extractNextData(html) {
  const match = html.match(
    /<script[^>]+id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/
  );
  if (!match) return void 0;
  try {
    return JSON.parse(match[1]);
  } catch (err) {
    console.warn("[vvs] failed to parse __NEXT_DATA__:", err);
    return void 0;
  }
}
function findProductArrays(node, out = []) {
  if (!node || typeof node !== "object") return out;
  if (Array.isArray(node)) {
    if (node.length > 0 && typeof node[0] === "object" && node[0] !== null && ("productNumber" in node[0] || "productId" in node[0])) {
      out.push(node);
    }
    for (const item of node) findProductArrays(item, out);
    return out;
  }
  for (const v of Object.values(node)) findProductArrays(v, out);
  return out;
}
async function searchSystembolaget(query, pageSize = 10) {
  const url = `${SITE}/sortiment/?q=${encodeURIComponent(query)}`;
  let res;
  try {
    res = await fetch(url, {
      headers: {
        Accept: "text/html,application/xhtml+xml",
        "Accept-Language": "sv-SE,sv;q=0.9,en;q=0.8",
        // Systembolaget's edge sometimes 403s requests without a UA.
        "User-Agent": "Mozilla/5.0 (compatible; vvs-extension/0.2)"
      }
    });
  } catch (err) {
    console.warn("[vvs] Systembolaget search fetch failed:", err);
    return [];
  }
  if (!res.ok) {
    if (res.status === 429 || res.status >= 500) {
      console.warn(`[vvs] Systembolaget search transient HTTP ${res.status}, returning []`);
      return [];
    }
    throw new Error(`Systembolaget search HTTP ${res.status}`);
  }
  const html = await res.text();
  const data = extractNextData(html);
  if (!data) {
    console.warn("[vvs] Systembolaget search: no __NEXT_DATA__ in response");
    return [];
  }
  const arrays = findProductArrays(data);
  arrays.sort((a, b) => b.length - a.length);
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const arr of arrays) {
    for (const raw of arr) {
      const p = toProduct(raw);
      if (!p) continue;
      if (seen.has(p.id)) continue;
      seen.add(p.id);
      out.push(p);
      if (out.length >= pageSize) return out;
    }
  }
  return out;
}

// src/lib/vinmonopolet.ts
var BASE = "https://www.vinmonopolet.no/vmpws/v2/vmp";
var SITE2 = "https://www.vinmonopolet.no";
function toProduct2(p) {
  const id = p.code;
  const name = (p.name ?? p.productLongName ?? p.productShortName ?? "").trim();
  const rawPrice = typeof p.price === "object" ? p.price?.value : p.price;
  const price = typeof rawPrice === "number" ? rawPrice : void 0;
  if (!id || !name || price == null) return void 0;
  const url = p.url ? p.url.startsWith("http") ? p.url : `${SITE2}${p.url}` : `${SITE2}/p/${id}`;
  const image = p.images?.find((i) => i.format === "product") ?? p.images?.[0];
  const imageUrl = image?.url ? image.url.startsWith("http") ? image.url : `https://bilder.vinmonopolet.no${image.url}` : void 0;
  const producerName = typeof p.producer === "string" ? p.producer : p.producer?.name ?? p.main_producer?.name;
  const rawVolume = typeof p.volume === "number" ? p.volume : p.volume?.value;
  const volumeMl = toMl(rawVolume);
  return {
    store: "vinmonopolet",
    id,
    name,
    producer: producerName,
    country: p.main_country?.name,
    category: p.main_category?.name,
    volumeMl,
    abv: p.alcohol?.value,
    vintage: p.year ? Number(p.year) || void 0 : void 0,
    price,
    currency: "NOK",
    url,
    imageUrl
  };
}
async function searchVinmonopolet(query, pageSize = 10) {
  try {
    const results = await searchVmpOccApi(query, pageSize);
    if (results.length > 0) {
      console.log("[vvs] Vinmonopolet OCC search got", results.length, "results");
      return results;
    }
  } catch (err) {
    console.warn("[vvs] Vinmonopolet OCC search failed:", err);
  }
  try {
    const results = await searchVmpHtml(query, pageSize);
    console.log("[vvs] Vinmonopolet HTML search got", results.length, "results");
    return results;
  } catch (err) {
    throw new Error(`Vinmonopolet search failed: ${err instanceof Error ? err.message : String(err)}`);
  }
}
async function searchVmpOccApi(query, pageSize) {
  const params = new URLSearchParams({
    query,
    pageSize: String(pageSize),
    currentPage: "0",
    fields: "FULL"
  });
  const url = `${BASE}/products/search?${params.toString()}`;
  const res = await fetch(url, {
    headers: {
      Accept: "application/json",
      "User-Agent": "Mozilla/5.0 (compatible; vvs-extension/0.2)"
    }
  });
  if (!res.ok) throw new Error(`OCC search HTTP ${res.status} for ${url}`);
  const json = await res.json();
  const products = json.productSearchResult?.products ?? json.products ?? [];
  return products.map(toProduct2).filter((p) => !!p);
}
async function searchVmpHtml(query, pageSize) {
  const url = `${SITE2}/search?q=${encodeURIComponent(query)}`;
  const res = await fetch(url, {
    headers: {
      Accept: "text/html,application/xhtml+xml",
      "Accept-Language": "nb-NO,nb;q=0.9,en;q=0.8",
      "User-Agent": "Mozilla/5.0 (compatible; vvs-extension/0.2)"
    }
  });
  if (!res.ok) throw new Error(`HTML search HTTP ${res.status} for ${url}`);
  const html = await res.text();
  return parseVmpSearchHtml(html, pageSize);
}
function parseVmpSearchHtml(html, pageSize) {
  const out = [];
  const seen = /* @__PURE__ */ new Set();
  const nextMatch = html.match(/<script[^>]+id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/);
  if (nextMatch) {
    try {
      const data = JSON.parse(nextMatch[1]);
      collectVmpProducts(data, seen, out, pageSize);
    } catch (err) {
      console.warn("[vvs] failed to parse Vinmonopolet __NEXT_DATA__:", err);
    }
  }
  if (out.length > 0) return out;
  const rx = /<script[^>]*type="application\/(?:ld\+)?json"[^>]*>([\s\S]*?)<\/script>/g;
  let m;
  while ((m = rx.exec(html)) && out.length < pageSize) {
    try {
      const data = JSON.parse(m[1]);
      collectVmpProducts(data, seen, out, pageSize);
    } catch {
    }
  }
  return out;
}
function collectVmpProducts(node, seen, out, pageSize) {
  if (out.length >= pageSize) return;
  if (!node || typeof node !== "object") return;
  if (Array.isArray(node)) {
    for (const item of node) {
      if (out.length >= pageSize) return;
      collectVmpProducts(item, seen, out, pageSize);
    }
    return;
  }
  const obj = node;
  const code = obj.code;
  const hasName = obj.name || obj.productShortName || obj.productLongName;
  if (typeof code === "string" && hasName && !seen.has(code)) {
    const p = toProduct2(obj);
    if (p) {
      seen.add(code);
      out.push(p);
      if (out.length >= pageSize) return;
    }
  }
  for (const v of Object.values(obj)) {
    if (out.length >= pageSize) return;
    collectVmpProducts(v, seen, out, pageSize);
  }
}

// src/lib/vinmonopoletOfficial.ts
async function hasVmpKey() {
  const { primary, secondary } = await getVmpKeys();
  return Boolean(primary || secondary);
}
async function searchVinmonopoletOfficial(_query, _pageSize = 15) {
  return [];
}

// src/background.ts
chrome.runtime.onInstalled.addListener(async () => {
  console.log("[vvs] installed");
  try {
    await getSekPerNok();
  } catch (err) {
    console.warn("[vvs] initial FX fetch failed:", err);
  }
});
chrome.tabs.onActivated.addListener(({ tabId }) => {
  void chrome.action.setBadgeText({ tabId, text: "" });
});
async function setBadge(tabId, text, color = "#e0b25a") {
  if (tabId == null) return;
  try {
    await chrome.action.setBadgeBackgroundColor({ tabId, color });
    await chrome.action.setBadgeText({ tabId, text });
  } catch (err) {
    console.warn("[vvs] setBadge failed:", err);
  }
}
chrome.runtime.onMessage.addListener(
  (message, sender, sendResponse) => {
    handleMessage(message, sender).then((data) => sendResponse({ ok: true, data })).catch(
      (err) => sendResponse({ ok: false, error: err instanceof Error ? err.message : String(err) })
    );
    return true;
  }
);
async function handleMessage(message, sender) {
  switch (message.type) {
    case "PING":
      return "pong";
    case "SCRIPT_LOADED": {
      console.log("[vvs] SCRIPT_LOADED from", message.store, message.url, "tabId=", sender.tab?.id);
      const badge = message.store === "systembolaget" ? "SE" : "NO";
      await setBadge(sender.tab?.id, badge, "#4a5568");
      return { acknowledged: true };
    }
    case "PAGE_PRODUCT":
      await setLastSeen(message.product);
      await setBadge(sender.tab?.id, "$", "#38a169");
      return { stored: true };
    case "GET_LAST_SEEN":
      return await getLastSeen();
    case "GET_LAST_COMPARISON":
      return await getLastComparison();
    case "FIND_MATCH":
      return await findMatch(message.product);
    default: {
      const _exhaustive = message;
      throw new Error(`Unknown message: ${JSON.stringify(_exhaustive)}`);
    }
  }
}
async function findMatch(source) {
  const queries = buildQueryVariants(source);
  console.log("[vvs] findMatch source:", {
    store: source.store,
    id: source.id,
    name: source.name,
    producer: source.producer,
    volumeMl: source.volumeMl,
    abv: source.abv
  });
  console.log("[vvs] findMatch query ladder:", queries);
  let candidates = [];
  let searchError;
  let usedQuery;
  for (const query of queries) {
    try {
      const results = source.store === "vinmonopolet" ? await searchSystembolaget(query, 15) : await searchVinmonopoletBest(query, 15);
      console.log(`[vvs] query "${query}" -> ${results.length} candidates`);
      if (results.length > 0) {
        candidates = results;
        usedQuery = query;
        break;
      }
    } catch (err) {
      searchError = err instanceof Error ? err.message : String(err);
      console.warn(`[vvs] query "${query}" failed:`, searchError);
    }
  }
  if (candidates.length === 0 && !searchError) {
    searchError = `No results for any of ${queries.length} query variants`;
    console.warn("[vvs]", searchError);
  } else if (candidates.length > 0) {
    console.log(
      `[vvs] using query "${usedQuery}" with`,
      candidates.length,
      "candidates:",
      candidates.slice(0, 5).map((c) => `${c.name} (${c.id})`)
    );
  }
  const ranked = topMatches(source, candidates, 4);
  const best = bestMatch(source, candidates);
  console.log("[vvs] best match:", best ? `${best.product.name} score=${best.score.toFixed(2)}` : "none");
  let se;
  let no;
  let score = 0;
  const alternates = ranked.filter((r) => !best || r.product.id !== best.product.id).slice(0, 3);
  if (source.store === "vinmonopolet") {
    no = source;
    if (best) {
      se = best.product;
      score = best.score;
    }
  } else {
    se = source;
    if (best) {
      no = best.product;
      score = best.score;
    }
  }
  const result = await compare(se, no, score, alternates);
  if (searchError) result.searchError = searchError;
  await setLastComparison(result);
  return result;
}
function buildQueryVariants(p) {
  const stop = /* @__PURE__ */ new Set([
    "the",
    "de",
    "la",
    "le",
    "les",
    "di",
    "du",
    "del",
    "della",
    "da",
    "og",
    "och",
    "and",
    "vin",
    "vino",
    "wine",
    "rouge",
    "blanc",
    "red",
    "white"
  ]);
  const tokens2 = p.name.replace(/\(.*?\)/g, " ").replace(/\b\d+(?:[.,]\d+)?\s?(?:cl|ml|l|%)\b/gi, " ").replace(/[^\p{Letter}\p{Number}\s-]/gu, " ").split(/\s+/).map((t) => t.trim()).filter((t) => t.length >= 3 && !stop.has(t.toLowerCase()) && !/^\d+$/.test(t));
  const variants = /* @__PURE__ */ new Set();
  if (p.producer && tokens2.length > 0) {
    const producerToken = p.producer.split(/\s+/).find((t) => t.length >= 3);
    if (producerToken) {
      variants.add(`${producerToken} ${tokens2[0]}`.trim());
      variants.add(producerToken);
    }
  }
  if (tokens2.length >= 3) variants.add(tokens2.slice(0, 3).join(" "));
  if (tokens2.length >= 2) variants.add(tokens2.slice(0, 2).join(" "));
  if (tokens2.length >= 1) variants.add(tokens2[0]);
  if (p.producer) {
    const producerToken = p.producer.split(/\s+/).find((t) => t.length >= 3);
    if (producerToken) variants.add(producerToken);
  }
  if (variants.size === 0) variants.add(p.name.slice(0, 40));
  return [...variants];
}
async function searchVinmonopoletBest(query, pageSize) {
  void hasVmpKey;
  void searchVinmonopoletOfficial;
  const results = await searchVinmonopolet(query, pageSize);
  console.log("[vvs] Vinmonopolet search got", results.length, "results for", JSON.stringify(query));
  return results;
}
//# sourceMappingURL=background.js.map
