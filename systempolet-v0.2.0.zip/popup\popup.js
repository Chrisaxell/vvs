// src/lib/storage.ts
var KEYS = {
  lastSeen: "lastSeenProduct",
  lastComparison: "lastComparison",
  fxRate: "fxRateSekPerNok",
  fxUpdatedAt: "fxUpdatedAt",
  vmpPrimaryKey: "vmpPrimaryKey",
  vmpSecondaryKey: "vmpSecondaryKey"
};
async function setFxRate(sekPerNok) {
  await chrome.storage.local.set({
    [KEYS.fxRate]: sekPerNok,
    [KEYS.fxUpdatedAt]: Date.now()
  });
}
async function getFxRate() {
  const res = await chrome.storage.local.get([KEYS.fxRate, KEYS.fxUpdatedAt]);
  const rate = res[KEYS.fxRate];
  const updatedAt = res[KEYS.fxUpdatedAt];
  if (rate == null || updatedAt == null) return void 0;
  return { rate, updatedAt };
}
async function setVmpKeys(keys) {
  await chrome.storage.local.set({
    [KEYS.vmpPrimaryKey]: keys.primary ?? "",
    [KEYS.vmpSecondaryKey]: keys.secondary ?? ""
  });
}
async function getVmpKeys() {
  const res = await chrome.storage.local.get([KEYS.vmpPrimaryKey, KEYS.vmpSecondaryKey]);
  return {
    primary: res[KEYS.vmpPrimaryKey] || void 0,
    secondary: res[KEYS.vmpSecondaryKey] || void 0
  };
}

// src/lib/currency.ts
var ONE_DAY_MS = 24 * 60 * 60 * 1e3;
var FALLBACK_SEK_PER_NOK = 0.92;
async function getSekPerNok() {
  const cached = await getFxRate();
  if (cached && Date.now() - cached.updatedAt < ONE_DAY_MS) {
    return cached.rate;
  }
  try {
    const res = await fetch("https://api.frankfurter.app/latest?from=NOK&to=SEK");
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    const rate = json.rates?.SEK;
    if (typeof rate !== "number" || !isFinite(rate)) throw new Error("Bad rate");
    await setFxRate(rate);
    return rate;
  } catch (err) {
    console.warn("[vvs] FX fetch failed, using fallback:", err);
    return cached?.rate ?? FALLBACK_SEK_PER_NOK;
  }
}

// src/lib/units.ts
function isNum(v) {
  return typeof v === "number" && Number.isFinite(v);
}
function formatVolume(ml) {
  if (ml == null || !isFinite(ml) || ml <= 0) return "";
  if (ml >= 1e3) {
    const l = ml / 1e3;
    if (Number.isInteger(l)) return `${l} L`;
    return `${l.toFixed(2).replace(/0+$/, "").replace(/\.$/, "")} L`;
  }
  if (ml % 10 === 0) return `${ml / 10} cl`;
  return `${ml} ml`;
}
function percentCheaper(cheaper, pricier) {
  if (!isNum(cheaper) || !isNum(pricier) || pricier <= 0) return void 0;
  if (cheaper >= pricier) return 0;
  return (pricier - cheaper) / pricier * 100;
}

// src/popup/popup.ts
var FLAG_SE = "\u{1F1F8}\u{1F1EA}";
var FLAG_NO = "\u{1F1F3}\u{1F1F4}";
var APPROX = "\u2248";
var DASH = "\u2014";
var ELLIP = "\u2026";
var ARROW = "\u2197";
var fxEl = document.getElementById("fx-value");
var lastSeenEl = document.getElementById("last-seen-body");
var comparisonEl = document.getElementById("comparison-body");
var contextEl = document.getElementById("context-body");
var refreshBtn = document.getElementById("refresh-btn");
var settingsStatusEl = document.getElementById("settings-status");
var vmpPrimaryEl = document.getElementById("vmp-primary");
var vmpSecondaryEl = document.getElementById("vmp-secondary");
var settingsSaveBtn = document.getElementById("settings-save");
var settingsClearBtn = document.getElementById("settings-clear");
var settingsShowBtn = document.getElementById("settings-show");
var settingsFeedbackEl = document.getElementById("settings-feedback");
async function sendMessage(message) {
  const res = await chrome.runtime.sendMessage(message);
  if (!res) return void 0;
  if (!res.ok) {
    console.warn("[vvs] popup message error:", res.error);
    return void 0;
  }
  return res.data;
}
function escapeHtml(s) {
  return s.replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] ?? c
  );
}
function flag(store) {
  return store === "systembolaget" ? FLAG_SE : FLAG_NO;
}
function productMetaBits(p) {
  const parts = [];
  const vol = formatVolume(p.volumeMl);
  if (vol) parts.push(vol);
  if (isNum(p.abv)) parts.push(`${p.abv.toFixed(1)}%`);
  if (p.vintage) parts.push(String(p.vintage));
  return parts.map(escapeHtml).join(" \xB7 ");
}
function renderProduct(p) {
  if (!p) {
    lastSeenEl.innerHTML = "<em>Visit a product page on systembolaget.se or vinmonopolet.no.</em>";
    return;
  }
  const price = isNum(p.price) ? `${p.price.toFixed(2)} ${p.currency}` : DASH;
  const meta = productMetaBits(p);
  const metaLine = meta ? `<div class="product-meta">${meta}</div>` : "";
  lastSeenEl.innerHTML = `
    <div class="product-name">${flag(p.store)} ${escapeHtml(p.name)}</div>
    ${metaLine}
    <div class="product-meta">${escapeHtml(p.store)} \xB7 <span class="price">${price}</span></div>
    <div class="product-meta"><a href="${escapeHtml(p.url)}" target="_blank" rel="noopener">Open page ${ARROW}</a></div>
  `;
}
function renderComparison(c) {
  if (!c || !c.se && !c.no && !(c.alternates && c.alternates.length)) {
    comparisonEl.innerHTML = "<em>No comparison yet.</em>";
    return;
  }
  const parts = [];
  let seSave;
  let noSave;
  if (c.se && c.no && isNum(c.fxRate) && isNum(c.se.price) && isNum(c.no.price)) {
    const usingPerLitre = isNum(c.seSekPerLitre) && isNum(c.noSekPerLitre);
    const seCmp = usingPerLitre ? c.seSekPerLitre : c.se.price;
    const noCmp = usingPerLitre ? c.noSekPerLitre : c.no.price * c.fxRate;
    const pct = percentCheaper(Math.min(seCmp, noCmp), Math.max(seCmp, noCmp));
    if (isNum(pct) && pct >= 1) {
      if (seCmp < noCmp) seSave = pct;
      else noSave = pct;
    }
  }
  if (c.se) parts.push(productLine(c.se, c.fxRate, c.seSekPerLitre, seSave));
  if (c.no) parts.push(productLine(c.no, c.fxRate, c.noSekPerLitre, noSave));
  if (isNum(c.priceDiffSek) && isNum(c.fxRate) && c.se && c.no && isNum(c.se.price) && isNum(c.no.price)) {
    const abs = Math.abs(c.priceDiffSek).toFixed(0);
    const noCheaper = c.priceDiffSek < 0;
    const cheaperFlag = noCheaper ? FLAG_NO : FLAG_SE;
    const cheaperName = noCheaper ? "Vinmonopolet" : "Systembolaget";
    const seSek = c.se.price;
    const noSek = c.no.price * c.fxRate;
    const bottlePct = percentCheaper(Math.min(seSek, noSek), Math.max(seSek, noSek)) ?? 0;
    let headlinePct = bottlePct;
    let headlineIsPerLitre = false;
    let headlineFlag = cheaperFlag;
    let headlineName = cheaperName;
    let perLitreDetail = "";
    if (isNum(c.seSekPerLitre) && isNum(c.noSekPerLitre)) {
      const seL = c.seSekPerLitre;
      const noL = c.noSekPerLitre;
      const perLitreCheaper = noL < seL;
      const perLitrePct = percentCheaper(Math.min(seL, noL), Math.max(seL, noL)) ?? 0;
      headlinePct = perLitrePct;
      headlineIsPerLitre = true;
      headlineFlag = perLitreCheaper ? FLAG_NO : FLAG_SE;
      headlineName = perLitreCheaper ? "Vinmonopolet" : "Systembolaget";
      perLitreDetail = `<div class="diff-sub">${Math.min(seL, noL).toFixed(0)} vs ${Math.max(seL, noL).toFixed(0)} SEK/L</div>`;
    }
    const perBottleDetail = headlineIsPerLitre ? `<div class="diff-sub">Per bottle: ${cheaperFlag} <strong>${cheaperName}</strong> saves <strong>${abs} SEK</strong> (${bottlePct.toFixed(0)}%)</div>` : `<div class="diff-sub">Saves <strong>${abs} SEK</strong> per bottle</div>`;
    const winnerClass = headlineName === "Vinmonopolet" ? "no" : "se";
    const unitLabel = headlineIsPerLitre ? "per litre" : "per bottle";
    parts.push(
      Math.abs(c.priceDiffSek) < 1 ? `<div class="diff neutral">Prices are essentially equal.</div>` : `<div class="diff ${winnerClass}">
             <div class="diff-headline">
               ${headlineFlag} <strong>${headlineName}</strong> is
               <span class="diff-pct">${headlinePct.toFixed(0)}%</span> cheaper
               <span class="diff-unit">${unitLabel}</span>
             </div>
             ${perLitreDetail}
             ${perBottleDetail}
           </div>`
    );
  }
  if (c.score > 0) {
    parts.push(`<div class="product-meta">match confidence: ${(c.score * 100).toFixed(0)}%</div>`);
  }
  const alternates = c.alternates ?? [];
  if (alternates.length) {
    const heading = c.se && c.no ? alternates.length === 1 ? "Other match" : `Other matches (${alternates.length})` : "Closest candidates";
    const openAttr = alternates.length > 1 || !(c.se && c.no) ? " open" : "";
    parts.push(`
      <details class="alts"${openAttr}>
        <summary><span class="label">${heading}</span></summary>
        <ul class="alt-list">
          ${alternates.map((a) => altLine(a.product, a.score)).join("")}
        </ul>
      </details>
    `);
  }
  comparisonEl.innerHTML = parts.join("");
}
function productLine(p, fxRate, sekPerLitre, savePct) {
  const price = isNum(p.price) ? `${p.price.toFixed(0)} ${p.currency}` : DASH;
  const sekEquiv = p.currency === "NOK" && isNum(fxRate) && isNum(p.price) ? ` <span class="price-sub">${APPROX} ${(p.price * fxRate).toFixed(0)} SEK</span>` : "";
  const perLitre = isNum(sekPerLitre) ? ` <span class="price-sub">(${sekPerLitre.toFixed(0)} SEK/L)</span>` : "";
  const vol = formatVolume(p.volumeMl);
  const volBadge = vol ? ` <span class="vol-badge">${escapeHtml(vol)}</span>` : "";
  const winner = isNum(savePct) && savePct >= 1;
  const saveBadge = winner ? ` <span class="save-badge">SAVE ${savePct.toFixed(0)}%</span>` : "";
  return `
    <div class="cmp-row${winner ? " winner" : ""}">
      <span>${flag(p.store)}</span>
      <a href="${escapeHtml(p.url)}" target="_blank" rel="noopener">${escapeHtml(p.name)}${volBadge}</a>
      <span class="price">${price}${sekEquiv}${perLitre}${saveBadge}</span>
    </div>
  `;
}
function altLine(p, score) {
  const price = isNum(p.price) ? `${p.price.toFixed(2)} ${p.currency}` : DASH;
  const vol = formatVolume(p.volumeMl);
  const volBadge = vol ? ` <span class="vol-badge">${escapeHtml(vol)}</span>` : "";
  return `
    <li>
      <a href="${escapeHtml(p.url)}" target="_blank" rel="noopener"
         title="match ${(score * 100).toFixed(0)}%">
        <span class="alt-name">${flag(p.store)} ${escapeHtml(p.name)}${volBadge}</span>
        <span class="price">${price}</span>
      </a>
    </li>
  `;
}
async function refresh() {
  fxEl.textContent = ELLIP;
  const [rate, last, comparison] = await Promise.all([
    getSekPerNok(),
    sendMessage({ type: "GET_LAST_SEEN" }),
    sendMessage({ type: "GET_LAST_COMPARISON" })
  ]);
  fxEl.textContent = `1 NOK ${APPROX} ${rate.toFixed(3)} SEK`;
  renderProduct(last);
  renderComparison(comparison);
  void renderContext();
}
var SB_URL = "https://www.systembolaget.se/";
var VMP_URL = "https://www.vinmonopolet.no/";
async function renderContext() {
  let host = "";
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.url) host = new URL(tab.url).hostname;
  } catch {
  }
  const onSb = host.endsWith("systembolaget.se");
  const onVmp = host.endsWith("vinmonopolet.no");
  if (onSb) {
    contextEl.innerHTML = `
      <div class="ctx-line">${FLAG_SE} You're on <strong>Systembolaget</strong>.</div>
      <div class="ctx-line muted">We'll show ${FLAG_NO} Vinmonopolet's price on product pages.</div>
      <a class="ctx-btn" href="${VMP_URL}" target="_blank" rel="noopener">${FLAG_NO} Open Vinmonopolet ${ARROW}</a>
    `;
    return;
  }
  if (onVmp) {
    contextEl.innerHTML = `
      <div class="ctx-line">${FLAG_NO} You're on <strong>Vinmonopolet</strong>.</div>
      <div class="ctx-line muted">We'll show ${FLAG_SE} Systembolaget's price on product pages.</div>
      <a class="ctx-btn" href="${SB_URL}" target="_blank" rel="noopener">${FLAG_SE} Open Systembolaget ${ARROW}</a>
    `;
    return;
  }
  contextEl.innerHTML = `
    <div class="ctx-line">Open one of the monopoly stores to start comparing:</div>
    <div class="ctx-btn-row">
      <a class="ctx-btn" href="${SB_URL}" target="_blank" rel="noopener">${FLAG_SE} Systembolaget</a>
      <a class="ctx-btn" href="${VMP_URL}" target="_blank" rel="noopener">${FLAG_NO} Vinmonopolet</a>
    </div>
  `;
}
async function loadSettings() {
  const keys = await getVmpKeys();
  vmpPrimaryEl.value = keys.primary ?? "";
  vmpSecondaryEl.value = keys.secondary ?? "";
  updateSettingsStatus();
}
function updateSettingsStatus() {
  const hasPrimary = vmpPrimaryEl.value.trim().length > 0;
  const hasSecondary = vmpSecondaryEl.value.trim().length > 0;
  if (hasPrimary && hasSecondary) {
    settingsStatusEl.textContent = "primary + secondary";
    settingsStatusEl.className = "settings-status ok";
  } else if (hasPrimary || hasSecondary) {
    settingsStatusEl.textContent = "configured";
    settingsStatusEl.className = "settings-status ok";
  } else {
    settingsStatusEl.textContent = "not configured";
    settingsStatusEl.className = "settings-status";
  }
}
function flashFeedback(msg, ok) {
  settingsFeedbackEl.textContent = msg;
  settingsFeedbackEl.className = `settings-feedback ${ok ? "ok" : "err"}`;
  window.setTimeout(() => {
    if (settingsFeedbackEl.textContent === msg) {
      settingsFeedbackEl.textContent = "";
      settingsFeedbackEl.className = "settings-feedback";
    }
  }, 4e3);
}
settingsSaveBtn.addEventListener("click", () => {
  const primary = vmpPrimaryEl.value.trim() || void 0;
  const secondary = vmpSecondaryEl.value.trim() || void 0;
  setVmpKeys({ primary, secondary }).then(() => {
    updateSettingsStatus();
    flashFeedback("Saved. Rotate any leaked keys in the portal!", true);
  }).catch((err) => flashFeedback(`Save failed: ${err instanceof Error ? err.message : String(err)}`, false));
});
settingsClearBtn.addEventListener("click", () => {
  vmpPrimaryEl.value = "";
  vmpSecondaryEl.value = "";
  setVmpKeys({}).then(() => {
    updateSettingsStatus();
    flashFeedback("Cleared.", true);
  }).catch((err) => flashFeedback(`Clear failed: ${err instanceof Error ? err.message : String(err)}`, false));
});
settingsShowBtn.addEventListener("click", () => {
  const revealed = vmpPrimaryEl.type === "text";
  vmpPrimaryEl.type = revealed ? "password" : "text";
  vmpSecondaryEl.type = revealed ? "password" : "text";
  settingsShowBtn.textContent = revealed ? "Show" : "Hide";
});
vmpPrimaryEl.addEventListener("input", updateSettingsStatus);
vmpSecondaryEl.addEventListener("input", updateSettingsStatus);
refreshBtn.addEventListener("click", () => {
  void refresh();
});
void refresh();
void loadSettings();
//# sourceMappingURL=popup.js.map
